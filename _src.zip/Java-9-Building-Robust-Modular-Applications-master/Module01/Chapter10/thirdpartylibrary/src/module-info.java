module thirdpartylibrary {
  requires stackwalker;
  exports packt.java9.deep.moduledemo.thirdpartylibrary;
}