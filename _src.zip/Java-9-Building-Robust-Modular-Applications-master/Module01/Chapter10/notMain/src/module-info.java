module notMain {
    requires mylibrary;

}