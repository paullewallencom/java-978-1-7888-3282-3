package packt.java9.deep.moduledemo.compiletime;

public class CompileTime {
}
