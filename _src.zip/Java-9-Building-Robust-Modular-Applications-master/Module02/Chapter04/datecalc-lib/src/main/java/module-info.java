module datecalc.lib {
    exports com.steeplesoft.datecalc;
}