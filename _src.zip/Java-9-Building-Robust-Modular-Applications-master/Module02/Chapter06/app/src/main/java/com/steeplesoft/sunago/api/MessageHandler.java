package com.steeplesoft.sunago.api;

import android.os.Handler;
import android.os.Message;

/**
 * Created by jason on 12/29/2016.
 */
public class MessageHandler extends Handler {
    @Override
    public void handleMessage(Message msg) {
        super.handleMessage(msg);
    }
}
