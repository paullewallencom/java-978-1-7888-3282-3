package com.steeplesoft.sunago;

import android.content.ComponentName;
import android.content.ServiceConnection;
import android.os.IBinder;
import android.util.Log;

public class PluginServiceConnection implements ServiceConnection {
    public void onServiceConnected(ComponentName className, IBinder boundService) {
    }

    public void onServiceDisconnected(ComponentName className) {
    }
}
